# TangLab 交互2.1

完整解压，运行 TangLab.exe；无需Python。旧版程序和用户记录在原TangLab文件夹保留。

- [详细操作指南](按键编码器与教学操作指南.txt)
- [操作图解](fpga/duo04-ui21/操作图解.md)
- [Gowin工程](fpga/duo04-ui21/tanglab_duo04.gprj)
- [验证记录](fpga/duo04-ui21/validation/RESULT.json)

本包不附新版.fs，须自行综合布线下载。旧2.0位流不能验证新增交互；PR1014及实物验收未闭环。软件与数字仿真不代表实物测试通过。
