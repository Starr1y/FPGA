# GEST27 第二轮布线结构修复（ROUTEFIX2）

工程入口：tanglab_duo04_score27_routefix2.gprj。顶层top_duo04，GW5AST-LV138PG484AC1/I0。
继续使用TangLab 2.7。由用户手工综合、布局布线、烧录；本版无.fs，不自动上传。

修改：滑音起点、每音保持快照、剩余计数改为同步RAM；有效位实现复位语义，剩余非零位供配置判断。配置仅在config_ready时接收，与渲染访问互斥。
并行PCM/包络/阶段等仍保留寄存器，使用已寄存的声部选择写入；调度器在已有ROM等待周期同时锁存频率与归属，下一周期进入乘法器，没有增加配置周期。

四音色、32声部、50MHz、48kHz、UART/Agent协议、曲谱教学和接线保持。CST/SDC与上一版逐字节相同。
请先综合，检查pitch_start、hold_snapshot、hold_remaining的RAM推断以及LUT/寄存器资源，再运行PNR。默认Route Option=2、时序驱动及保持修正开启。
布线要求零未布通、setup/hold满足约束并核对PR1014。不能从仿真通过推断实际可布通。
上版169条未布通网络为基线；本版资源与布线耗时尚未实测。

验证证据见validation；旧说明文件仅为历史参考，本轮状态以BUILD_STATUS.json和本README为准。
