# 2026-10-28 布线修复

先读《布线修复说明-20261028.txt》。原位更新RTL，需要重新综合再布线；恢复配置Route Option1。旧网表和失败报告保留用于取证，不能拿来验证修改后的源码。上位机2.7继续使用。

# TangLab 2.7 / GEST27

基于GEST26的新独立工程：09曲谱上传与教学、双区RAM CRC提交与读回、自动目标C档、HDMI双扇区逐音教学。保留四音色/32声部、IMU、鼠标、波形与Agent；不包含已验证新版位流。

先读《曲谱上传与脱机教学指南.txt》。工程入口`tanglab_duo04_score27.gprj`，顶层`top_duo04`，GW5AST138C PG484。综合/布局布线/下载由用户执行；Route Option2、时序驱动与保持修正开启，50MHz不放宽。`check_implementation.py`仅读取后续报告。

本轮源码/仿真与程序证据见validation及交付包验证记录。setup/hold、PR1014、资源和硬件教学待用户实现后检查。目录内其他手势/接线说明沿用GEST26，标为基线功能资料；audio-preview/preview为基线试听和画面，不能当GEST27上板证据。
