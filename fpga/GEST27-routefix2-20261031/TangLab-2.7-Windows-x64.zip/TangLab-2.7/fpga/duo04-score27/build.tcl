set root [file dirname [file normalize [info script]]]
cd $root
open_project tanglab_duo04_score27.gprj
set_option -top_module top_duo04
# Routing-repair recovery: prioritize completion with option1; source structure also changed.
set_option -route_option 1
set_option -timing_driven 1
run all
