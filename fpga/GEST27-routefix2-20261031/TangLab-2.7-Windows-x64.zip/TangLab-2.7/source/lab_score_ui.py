"""Page09: validate -> adapt -> upload -> board-owned lesson. AI is a stub."""
import json,shutil
from pathlib import Path
from PySide6 import QtCore as C,QtWidgets as W
from lab_score import load_score,compile_score,AIConversionAdapter,ASSETS
from lab_duo_ui import MouseFan

def build(g):
    p=W.QWidget();outer=W.QVBoxLayout(p);scroll=W.QScrollArea();scroll.setWidgetResizable(True);body=W.QWidget();col=W.QVBoxLayout(body);scroll.setWidget(body);outer.addWidget(scroll);g.tabs.addTab(p,'09 曲谱上传与教学')
    g.score_input=None;g.score_preview=None;g.score_job=None;g.score_seen=-1
    col.addWidget(W.QLabel('统一文件导入 → 校验与音域预览 → 上传并完整读回 → 逐音等待教学。板内曲目断电丢失，电脑曲库长期保留。'))
    row=W.QHBoxLayout()
    def button(text,fn):
        b=W.QPushButton(text);b.clicked.connect(lambda:g.safe(fn));row.addWidget(b);return b
    def import_file():
        path,_=W.QFileDialog.getOpenFileName(g,'导入统一曲谱','','TangLab曲谱 (*.tangscore.json);;JSON (*.json)')
        if path:set_score(g,load_score(path))
    button('导入统一文件',import_file);button('载入示例',lambda:set_score(g,load_score(ASSETS/'左右手练习.tangscore.json')))
    g.score_layout=W.QComboBox();g.score_layout.addItems(['自动：自然音七区／含半音十二区','七音区','五音区','十二音区']);g.score_layout.currentIndexChanged.connect(lambda:g.safe(lambda:preview(g)));row.addWidget(g.score_layout)
    button('四音色曲谱模拟（非实物）',lambda:g.submit_command('score.demo'));col.addLayout(row)
    g.score_summary=W.QLabel('尚未导入曲谱');g.score_summary.setWordWrap(True);col.addWidget(g.score_summary)
    g.score_table=W.QTableWidget(0,8);g.score_table.setHorizontalHeaderLabels(['步骤','手','原音','适配后音','音区','C档','保持ms','前置休止ticks'])
    g.score_table.setEditTriggers(W.QAbstractItemView.EditTrigger.NoEditTriggers);g.score_table.horizontalHeader().setSectionResizeMode(W.QHeaderView.ResizeMode.Stretch);g.score_table.setMinimumHeight(180);g.score_table.setMaximumHeight(280);col.addWidget(g.score_table)
    g.score_changes=W.QPlainTextEdit();g.score_changes.setReadOnly(True);g.score_changes.setMaximumHeight(90);col.addWidget(g.score_changes)
    g.score_confirm=W.QCheckBox('我已检查并同意上方八度／时值适配（仅有改动时必选）');col.addWidget(g.score_confirm)
    row=W.QHBoxLayout()
    def save():
        if not g.score_preview:raise ValueError('先导入并校验曲谱')
        folder=W.QFileDialog.getExistingDirectory(g,'选择电脑曲库保存目录')
        if folder:
            path=Path(folder)/(g.score_preview['score']['title'].translate(str.maketrans({c:'_' for c in '<>:"/\\|?*'}))+'.tangscore.json')
            if path.exists() and W.QMessageBox.question(g,'覆盖曲库文件','此曲名已存在，覆盖吗？')!=W.QMessageBox.StandardButton.Yes:return
            path.write_text(json.dumps(g.score_preview['score'],ensure_ascii=False,indent=2),encoding='utf8');g.score_summary.setText('电脑曲库已保存：'+str(path))
    button('保存到电脑曲库',save)
    def export():
        if not g.score_preview:raise ValueError('先导入曲谱')
        path,_=W.QFileDialog.getSaveFileName(g,'导出适配曲谱','适配曲谱.tangscore.json','TangLab曲谱 (*.tangscore.json)')
        if path:Path(path).write_text(json.dumps(g.score_preview['adapted'],ensure_ascii=False,indent=2),encoding='utf8')
    button('导出适配后文件',export)
    g.score_upload_button=button('上传并完整校验',lambda:upload(g))
    button('取消上传',lambda:g.controller.cancel(g.score_job) if g.score_job else None)
    button('读取板上曲目状态',lambda:g.submit_command('score.status'));col.addLayout(row)
    g.score_progress=W.QProgressBar();g.score_progress.setRange(0,100);col.addWidget(g.score_progress)
    g.score_status=W.QLabel('旧固件不支持上传；需要GEST27，发送成功不等于校验完成。');g.score_status.setWordWrap(True);col.addWidget(g.score_status)
    row=W.QHBoxLayout();g.score_source=W.QComboBox();g.score_source.addItems(['真实IMU脱机教学','鼠标教学测试']);row.addWidget(g.score_source)
    button('选择导入曲目与来源（先停止）',lambda:g.submit_command('lesson.configure',dict(source='mouse' if g.score_source.currentIndex() else 'imu',lesson=3)))
    for text,action in [('开始','start'),('暂停','pause'),('继续','resume'),('重来','restart'),('停止','stop')]:button(text,lambda a=action:g.submit_command('lesson.control',{'action':a}))
    col.addLayout(row);g.score_target=W.QLabel('目标：等待板上读回');col.addWidget(g.score_target)
    row=W.QHBoxLayout();g.score_fans=[]
    def strike(h,z):
        e=g.engine
        if e.instrument_state.get('mode')!=2 or e.instrument_state.get('lesson_source')!=1:raise ValueError('请先选择鼠标教学测试并开始')
        if e.score_state.get('feedback')==1:raise ValueError('正确反馈期间请等待下一目标')
        g.submit_command('duo.strike',dict(hand=h,zone=z,profile=e.duo_config['profiles'][h],octave=0,velocity=40,capture=False))
    for h,name in enumerate(('左手','右手')):
        box=W.QGroupBox(name+'：鼠标移动预选、按下击发');layout=W.QVBoxLayout(box);fan=MouseFan(h);fan.setMinimumHeight(150);fan.struck.connect(lambda z,hand=h:g.safe(lambda:strike(hand,z)));layout.addWidget(fan);row.addWidget(box);g.score_fans.append(fan)
    col.addLayout(row)
    ai=W.QGroupBox('AI转换接口预留 · 尚未接入模型');form=W.QFormLayout(ai)
    g.score_ai_url=W.QLineEdit();g.score_ai_url.setPlaceholderText('服务地址（以后接入）');g.score_ai_model=W.QLineEdit();g.score_ai_key=W.QLineEdit();g.score_ai_key.setEchoMode(W.QLineEdit.EchoMode.Password)
    form.addRow('服务地址',g.score_ai_url);form.addRow('模型名',g.score_ai_model);form.addRow('密钥（仅当前会话）',g.score_ai_key)
    b=W.QPushButton('AI转换（尚未接入）');b.setEnabled(False);form.addRow(b)
    form.addRow(W.QLabel('当前不发送网络请求，不保存密钥。请用外部AI按转换规范生成纯JSON，然后导入。'))
    row=W.QHBoxLayout()
    def copy_rules():W.QApplication.clipboard().setText((ASSETS/'给AI的转换提示词.txt').read_text(encoding='utf8'))
    button('复制给AI的转换规则',copy_rules);button('打开格式规范',lambda:g.open_file(ASSETS/'曲谱格式规范.md'));form.addRow(row);col.addWidget(ai);col.addStretch()

def set_score(g,score):g.score_input=score;g.score_confirm.setChecked(False);preview(g)

def preview(g):
    g.score_preview=None
    if g.score_input is None:return
    layout='auto' if g.score_layout.currentIndex()==0 else g.score_layout.currentIndex()-1
    out=compile_score(g.score_input,layout);g.score_preview=out;g.score_confirm.setChecked(False)
    g.score_summary.setText(f"{out['score']['title']} · {out['count']}步 · 布局{[7,5,12][out['profile']]}音区 · CRC32 {out['crc32']:08X}；教学自动目标C档，时值只控制发声保持，不按节拍评分。")
    g.score_table.setRowCount(len(out['rows']))
    from lab_score import note_name
    for i,r in enumerate(out['rows']):
        values=[i+1,'右' if r['hand']=='right' else '左',note_name(r['original_midi']),r['note'],r['zone']+1,r['midi']//12-1,r['hold_ms'],r['rest_before_ticks']]
        for k,v in enumerate(values):g.score_table.setItem(i,k,W.QTableWidgetItem(str(v)))
    g.score_changes.setPlainText('\n'.join(out['changes']+out['warnings']) or '无需音域／时值适配。自然衰减可能早于松键变轻。')

def upload(g):
    if not g.score_preview:raise ValueError('请先导入并校验曲谱')
    if g.score_preview['requires_confirmation'] and not g.score_confirm.isChecked():raise ValueError('请先确认适配内容')
    g.stop_live('曲谱上传已停止自动采样');g.duo_sync.setChecked(False)
    p=dict(score=g.score_input,layout='auto' if g.score_layout.currentIndex()==0 else g.score_layout.currentIndex()-1,confirmed=g.score_confirm.isChecked())
    g.score_job=g.submit_command('score.upload',p)['id']

def refresh(g):
    if not hasattr(g,'score_status'):return
    e=g.engine;s=e.score_state;ready=e.ready and e.capabilities.get('score_v1',False)
    g.score_upload_button.setEnabled(ready and g.score_preview is not None)
    if g.score_job:
        j=g.controller.job(g.score_job);g.score_status.setText(j['message']);g.score_progress.setValue(round(100*j.get('progress',0)))
        if j['state']=='completed':g.score_progress.setValue(100)
    elif not ready:g.score_status.setText('需要连接GEST27固件或运行曲谱模拟。旧固件的原有功能保留。')
    else:g.score_status.setText(f"板内曲目：{'已校验' if s.get('loaded') else '未上传'}；{s.get('total',0)}步，CRC {s.get('crc32',0):08X}；断电丢失。")
    if s.get('selected'):
        g.score_target.setText(f"目标 {'右' if s.get('hand') else '左'}手 · 音区{s.get('zone',0)+1} · MIDI {s.get('note',60)} · C{[4,5,2,3][s.get('octave',0)]} · {min(s.get('position',0)+1,s.get('total',0))}/{s.get('total',0)} · 正确{s.get('correct',0)} / 错击{s.get('wrong',0)} · {'已完成' if s.get('finished') else '自动按目标设档'}")
    for h,fan in enumerate(g.score_fans):
        profile=s.get('profile',0)
        if fan.profile!=profile:fan.profile=profile;fan.hover=None
        fan.lesson_target=s.get('zone') if s.get('selected') and not s.get('finished') and s.get('hand')==h else None
        fan.lesson_feedback=e.instrument_state.get('feedback',0) if e.instrument_state.get('feedback_hand')==h else 0
        fan.lesson_feedback_zone=e.instrument_state.get('feedback_zone');fan.update()
