# TangLab 2.7 曲谱教学便携包

双击TangLab.exe，完整目录可移动，接收者无需Python。请发送整个ZIP，解压后运行，不要只发EXE。目标Windows10/11 x64；只在本机测试，其他电脑未实测。硬件驱动/Gowin另装，Gowin不包含在包内。

新工程：fpga/duo04-score27/tanglab_duo04_score27.gprj。按《使用说明.txt》手工综合、布局布线、检查时序后下载，包内无GEST27可烧录.fs。先在09运行曲谱模拟，再做真实上板。AI仅预留，不联网。曲谱文件和Schema见source/score_assets。验证记录区分模拟/RTL/未上板，不把仿真当实测。

构建：Python3.12 x64创建虚拟环境，pip install -r requirements-lock.txt；python source/build_gesture24.py --output "D:/你的输出/TangLab" --work "D:/你的构建目录"。打包时确保score_assets随包，构建工具不运行FPGA编译。主程序/CLI源码与依赖许可均附，新增协议见docs/GEST27曲谱协议.md。
